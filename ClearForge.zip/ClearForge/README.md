# ClearForge

On-device video and photo enhancer for Android: upscale, sharpen, denoise, clarity. Everything runs on the phone's GPU and hardware codecs. Nothing is uploaded.

## Build

1. Install Android Studio (Ladybug 2024.2 or newer) with Android SDK 35.
2. File > Open, choose this folder, let Gradle sync (Android Studio creates the Gradle wrapper for you).
3. Plug in a phone (Android 10+, OpenGL ES 3.0) and press Run. Test on a real device, not the emulator: the emulator's video codecs and GPU are unreliable for this.

## How it works

Decode (MediaCodec) -> GPU passes -> encode (MediaCodec, HEVC or H.264) -> MP4. Audio is copied untouched.

| Pass | What it does |
|------|--------------|
| Clean | Deblocks 8px compression seams, then edge-preserving bilateral denoise |
| Upscale | Separable Lanczos-3 to the target size, with a halo guard against the source |
| Wide blur | 1/4-res blur used as the base for local contrast |
| Finish | Contrast-adaptive sharpening, noise-gated detail boost, clarity, ring clamp, color, optional grain, dither |

Intermediate buffers are 16-bit float when the GPU supports it, so denoise and resampling do not band.

## Honest limits

- This is a high-quality classical GPU pipeline, not a neural network. It will look clearly better than a normal upscale, but it cannot invent detail the way AI models such as Topaz's do. A neural pass (for example a TFLite Real-ESRGAN model) could be added as an extra stage between "Upscale" and "Finish".
- Output is capped at 4096 px on the long side.
- HDR (HLG/PQ) sources are exported as SDR without tone mapping. The export screen warns when it detects one.
- No frame interpolation, stabilization or deinterlacing yet.
- Speed depends on the phone. Expect real-time or slower for 1080p to 4K targets on mid-range devices.
