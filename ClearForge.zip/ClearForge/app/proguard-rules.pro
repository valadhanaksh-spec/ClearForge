# ClearForge release rules. Engine uses only platform APIs (MediaCodec, GLES), nothing to keep.
