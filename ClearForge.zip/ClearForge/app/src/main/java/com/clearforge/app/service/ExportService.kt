package com.clearforge.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.clearforge.app.MainActivity
import com.clearforge.app.R
import com.clearforge.app.engine.ExportProgress
import com.clearforge.app.engine.VideoEnhancer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps long exports alive when the app is backgrounded or the screen turns off. */
class ExportService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            job?.cancel()
            return START_NOT_STICKY
        }
        val req = ExportManager.pending
        if (req == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(-1f, "Preparing…"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "clearforge:export").apply {
            acquire(4 * 60 * 60 * 1000L)
        }
        job?.cancel()
        job = scope.launch { runExport(req) }
        return START_NOT_STICKY
    }

    private suspend fun runExport(req: ExportRequest) {
        ExportManager.set(ExportUiState.Running(null, req.sourceName))
        val tmp = File(cacheDir, "exports/${System.currentTimeMillis()}.mp4")
        try {
            val result = VideoEnhancer(applicationContext).enhance(req.input, tmp, req.settings) { p ->
                ExportManager.set(ExportUiState.Running(p, req.sourceName))
                updateNotification(p)
            }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val name = "ClearForge_${stamp}_${result.outW}x${result.outH}.mp4"
            val uri = MediaStoreSaver.saveVideo(applicationContext, tmp, name)
            ExportManager.set(ExportUiState.Done(uri, result, name))
        } catch (e: CancellationException) {
            ExportManager.set(ExportUiState.Idle)
            throw e
        } catch (t: Throwable) {
            ExportManager.set(ExportUiState.Failed(t.message ?: t.javaClass.simpleName))
        } finally {
            tmp.delete()
            wakeLock?.let { if (it.isHeld) it.release() }
            ExportManager.pending = null
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        job?.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    // ------------------------------------------------------------ notification

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun updateNotification(p: ExportProgress) {
        val pct = (p.fraction * 100).toInt()
        val eta = if (p.etaSeconds >= 0) " · ${formatEta(p.etaSeconds)} left" else ""
        val text = "$pct% · ${"%.1f".format(Locale.US, p.fps)} fps$eta"
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(p.fraction, text))
    }

    private fun buildNotification(fraction: Float, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val cancel = PendingIntent.getService(
            this, 1, Intent(this, ExportService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Enhancing video")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Cancel", cancel)
            .apply {
                if (fraction < 0f) setProgress(0, 0, true) else setProgress(100, (fraction * 100).toInt(), false)
            }
            .build()
    }

    companion object {
        const val ACTION_CANCEL = "com.clearforge.app.CANCEL_EXPORT"
        private const val CHANNEL_ID = "export"
        private const val NOTIF_ID = 42

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, ExportService::class.java))
        }

        fun cancel(ctx: Context) {
            ctx.startService(Intent(ctx, ExportService::class.java).setAction(ACTION_CANCEL))
        }

        fun formatEta(sec: Int): String =
            if (sec >= 3600) "${sec / 3600}h ${(sec % 3600) / 60}m"
            else if (sec >= 60) "${sec / 60}m ${sec % 60}s" else "${sec}s"
    }
}
