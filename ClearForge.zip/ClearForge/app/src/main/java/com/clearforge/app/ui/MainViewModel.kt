package com.clearforge.app.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.clearforge.app.engine.EnhanceSettings
import com.clearforge.app.engine.Presets
import com.clearforge.app.engine.StillProcessor
import com.clearforge.app.engine.computeOutputSize
import com.clearforge.app.service.ExportManager
import com.clearforge.app.service.ExportRequest
import com.clearforge.app.service.ExportService
import com.clearforge.app.service.MediaStoreSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

data class MediaSource(
    val uri: Uri,
    val name: String,
    val isVideo: Boolean,
    val width: Int,
    val height: Int,
    val durationMs: Long,
    val fps: Float
)

data class EditorState(
    val source: MediaSource? = null,
    val settings: EnhanceSettings = Presets.all[0].settings,
    val presetIndex: Int = 0,
    val thumb: Bitmap? = null,
    val cropOriginal: Bitmap? = null,
    val cropEnhanced: Bitmap? = null,
    val previewBusy: Boolean = false,
    val previewCenterX: Float = 0.5f,
    val previewCenterY: Float = 0.5f,
    val positionMs: Long = 0,
    val loading: Boolean = false,
    val busyMessage: String? = null,
    val message: String? = null,
    val savedPhoto: Uri? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(EditorState())
    val state: StateFlow<EditorState> = _state
    val export = ExportManager.state

    private val still = StillProcessor()
    private var fullFrame: Bitmap? = null
    private var previewJob: Job? = null

    // ------------------------------------------------------------------ loading

    fun onPicked(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, message = null, savedPhoto = null) }
            try {
                val ctx = getApplication<Application>()
                val isImage = ctx.contentResolver.getType(uri)?.startsWith("image/") == true
                val name = queryName(uri)
                val (src, frame) = withContext(Dispatchers.IO) {
                    if (isImage) loadPhoto(uri, name) else loadVideo(uri, name, 0L)
                }
                fullFrame = frame
                _state.update {
                    it.copy(
                        source = src, loading = false, positionMs = 0,
                        previewCenterX = 0.5f, previewCenterY = 0.5f,
                        thumb = makeThumb(frame), cropOriginal = null, cropEnhanced = null
                    )
                }
                refreshPreview(immediate = true)
            } catch (t: Throwable) {
                _state.update { it.copy(loading = false, message = "Could not open that file: ${t.message ?: t.javaClass.simpleName}") }
            }
        }
    }

    private fun queryName(uri: Uri): String {
        val ctx = getApplication<Application>()
        return runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull() ?: "media"
    }

    private fun loadPhoto(uri: Uri, name: String): Pair<MediaSource, Bitmap> {
        val ctx = getApplication<Application>()
        val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            if (max(info.size.width, info.size.height) > 6000) dec.setTargetSampleSize(2)
        }
        return MediaSource(uri, name, false, bmp.width, bmp.height, 0L, 0f) to bmp
    }

    private fun loadVideo(uri: Uri, name: String, atMs: Long): Pair<MediaSource, Bitmap> {
        val ctx = getApplication<Application>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val frames = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toLongOrNull()
            val fps = if (frames != null && dur > 0) frames * 1000f / dur else 30f
            val frame = r.getFrameAtTime(atMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: throw IllegalStateException("No decodable video frames")
            // frame is already upright (rotation applied), so its size is the display size
            return MediaSource(uri, name, true, frame.width, frame.height, dur, fps) to frame
        } finally {
            r.release()
        }
    }

    private fun makeThumb(frame: Bitmap): Bitmap {
        val k = 360f / max(frame.width, frame.height)
        return if (k >= 1f) frame else Bitmap.createScaledBitmap(frame, (frame.width * k).toInt(), (frame.height * k).toInt(), true)
    }

    // ------------------------------------------------------------------ controls

    fun applyPreset(index: Int) {
        val p = Presets.all[index]
        _state.update { it.copy(settings = p.settings, presetIndex = index) }
        refreshPreview()
    }

    fun edit(block: (EnhanceSettings) -> EnhanceSettings) {
        _state.update { it.copy(settings = block(it.settings), presetIndex = -1) }
        refreshPreview()
    }

    fun setPreviewCenter(x: Float, y: Float) {
        _state.update { it.copy(previewCenterX = x.coerceIn(0f, 1f), previewCenterY = y.coerceIn(0f, 1f)) }
        refreshPreview()   // debounced, so dragging doesn't queue a GL job per touch event
    }

    fun closeSource() {
        previewJob?.cancel()
        fullFrame = null
        _state.update { EditorState() }
    }

    fun seekTo(ms: Long) {
        val src = _state.value.source ?: return
        if (!src.isVideo) return
        _state.update { it.copy(positionMs = ms) }
        viewModelScope.launch {
            try {
                val (_, frame) = withContext(Dispatchers.IO) { loadVideo(src.uri, src.name, ms) }
                fullFrame = frame
                _state.update { it.copy(thumb = makeThumb(frame)) }
                refreshPreview(immediate = true)
            } catch (t: Throwable) {
                _state.update { it.copy(message = "Could not read that frame") }
            }
        }
    }

    fun dismissMessage() = _state.update { it.copy(message = null) }

    // ------------------------------------------------------------------ preview

    /** Re-run the pipeline on a native-resolution crop so the preview shows true per-pixel quality. */
    private fun refreshPreview(immediate: Boolean = false) {
        previewJob?.cancel()
        val frame = fullFrame ?: return
        previewJob = viewModelScope.launch {
            if (!immediate) delay(220)
            _state.update { it.copy(previewBusy = true) }
            try {
                val s = _state.value
                val cw = min(frame.width, CROP_W)
                val ch = min(frame.height, CROP_H)
                val x = (s.previewCenterX * frame.width - cw / 2f).toInt().coerceIn(0, frame.width - cw)
                val y = (s.previewCenterY * frame.height - ch / 2f).toInt().coerceIn(0, frame.height - ch)
                val crop = withContext(Dispatchers.Default) { Bitmap.createBitmap(frame, x, y, cw, ch) }
                val out = still.process(crop, s.settings)
                _state.update { it.copy(cropOriginal = crop, cropEnhanced = out, previewBusy = false) }
            } catch (t: kotlinx.coroutines.CancellationException) {
                throw t
            } catch (t: Throwable) {
                _state.update { it.copy(previewBusy = false, message = "Preview failed: ${t.message ?: t.javaClass.simpleName}") }
            }
        }
    }

    // ------------------------------------------------------------------ export

    fun outputSize(): Pair<Int, Int>? {
        val s = _state.value
        val src = s.source ?: return null
        return computeOutputSize(src.width, src.height, s.settings.scale)
    }

    fun startExport() {
        val s = _state.value
        val src = s.source ?: return
        if (src.isVideo) {
            ExportManager.pending = ExportRequest(src.uri, src.name, s.settings)
            ExportManager.set(com.clearforge.app.service.ExportUiState.Running(null, src.name))
            ExportService.start(getApplication())
        } else {
            exportPhoto(src, s.settings)
        }
    }

    private fun exportPhoto(src: MediaSource, settings: EnhanceSettings) {
        viewModelScope.launch {
            _state.update { it.copy(busyMessage = "Enhancing photo…", message = null, savedPhoto = null) }
            try {
                val ctx = getApplication<Application>()
                val full = withContext(Dispatchers.IO) { loadPhoto(src.uri, src.name).second }
                val out = still.process(full, settings)
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val uri = withContext(Dispatchers.IO) {
                    MediaStoreSaver.savePhoto(ctx, out, "ClearForge_${stamp}_${out.width}x${out.height}.jpg")
                }
                _state.update { it.copy(busyMessage = null, savedPhoto = uri) }
            } catch (t: Throwable) {
                _state.update { it.copy(busyMessage = null, message = "Photo export failed: ${t.message ?: t.javaClass.simpleName}") }
            }
        }
    }

    fun cancelExport() = ExportService.cancel(getApplication())

    fun resetExport() = ExportManager.reset()

    override fun onCleared() {
        still.release()
        super.onCleared()
    }

    private companion object {
        const val CROP_W = 480
        const val CROP_H = 320
    }
}
