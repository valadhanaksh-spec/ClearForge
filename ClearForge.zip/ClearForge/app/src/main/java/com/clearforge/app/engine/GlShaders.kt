package com.clearforge.app.engine

/**
 * GLSL ES 3.00 sources for the enhancement pipeline.
 *
 * Pass order (all intermediate textures are RGBA8, "GL-up" orientation):
 *   P0  copy      : video OES texture (or bitmap) -> src-res texture
 *   P1  clean     : deblock + edge-preserving bilateral denoise (src res)
 *   P2a lanczosH  : Lanczos-3 horizontal resample to output width
 *   P2b lanczosV  : Lanczos-3 vertical resample to output height + anti-ring vs. source
 *   P3  blur      : wide blur at 1/4 output res (feeds local-contrast "clarity")
 *   P4  finish    : CAS sharpen, detail boost, clarity, ring clamp, color, grain, dither
 */
object GlShaders {

    const val VERTEX = """#version 300 es
layout(location = 0) in vec2 aPos;
uniform mat4 uTexMatrix;
uniform float uFlipY;
out vec2 vUv;
void main() {
    vec2 uv = aPos * 0.5 + 0.5;
    uv.y = mix(uv.y, 1.0 - uv.y, uFlipY);
    vUv = (uTexMatrix * vec4(uv, 0.0, 1.0)).xy;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""

    const val COPY_OES = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
precision highp int;
uniform samplerExternalOES uTex;
in vec2 vUv;
out vec4 o;
void main() { o = vec4(texture(uTex, vUv).rgb, 1.0); }
"""

    const val COPY_2D = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uTex;
in vec2 vUv;
out vec4 o;
void main() { o = vec4(texture(uTex, vUv).rgb, 1.0); }
"""

    /** Deblock on an 8px grid, then 5x5 bilateral denoise. Source-res, uses texelFetch. */
    const val CLEAN = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uTex;
uniform float uDenoise;
uniform float uDeblock;
out vec4 o;

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

vec3 fetch(ivec2 p, ivec2 sz) {
    return texelFetch(uTex, clamp(p, ivec2(0), sz - 1), 0).rgb;
}

void main() {
    ivec2 sz = textureSize(uTex, 0);
    ivec2 p = ivec2(gl_FragCoord.xy);
    vec3 c = fetch(p, sz);

    // ---- deblock: soften small steps that sit exactly on 8px block seams ----
    if (uDeblock > 0.001) {
        float thr = mix(0.02, 0.14, uDeblock);
        int mx = p.x & 7;
        int my = p.y & 7;
        vec3 acc = c;
        if (mx == 0 || mx == 7) {
            vec3 n = fetch(p + ivec2(mx == 0 ? -1 : 1, 0), sz);
            float d = abs(luma(c) - luma(n));
            if (d < thr) acc = mix(acc, 0.5 * (c + n), 0.55 * uDeblock * (1.0 - d / thr));
        }
        if (my == 0 || my == 7) {
            vec3 n = fetch(p + ivec2(0, my == 0 ? -1 : 1), sz);
            float d = abs(luma(c) - luma(n));
            if (d < thr) acc = mix(acc, 0.5 * (c + n), 0.55 * uDeblock * (1.0 - d / thr));
        }
        c = acc;
    }

    // ---- bilateral denoise (edge preserving) ----
    if (uDenoise > 0.001) {
        float sigmaS = 1.3;
        float sigmaR = mix(0.02, 0.20, uDenoise);
        float inv2s = 1.0 / (2.0 * sigmaS * sigmaS);
        float inv2r = 1.0 / (2.0 * sigmaR * sigmaR);
        vec3 sum = vec3(0.0);
        float wsum = 0.0;
        for (int j = -2; j <= 2; j++) {
            for (int i = -2; i <= 2; i++) {
                vec3 s = fetch(p + ivec2(i, j), sz);
                vec3 dc = s - c;
                float w = exp(-float(i * i + j * j) * inv2s - dot(dc, dc) * inv2r);
                sum += s * w;
                wsum += w;
            }
        }
        vec3 f = sum / wsum;
        c = mix(c, f, clamp(uDenoise * 1.6, 0.0, 1.0));
    }
    o = vec4(c, 1.0);
}
"""

    private const val LANCZOS_COMMON = """
float lanczos3(float x) {
    x = abs(x);
    if (x < 1e-4) return 1.0;
    if (x >= 3.0) return 0.0;
    float px = 3.14159265 * x;
    return 3.0 * sin(px) * sin(px / 3.0) / (px * px);
}
"""

    /** Horizontal Lanczos-3. Output is (outW x srcH). */
    const val LANCZOS_H = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uTex;
uniform vec2 uOutSize;
out vec4 o;
$LANCZOS_COMMON
void main() {
    ivec2 sz = textureSize(uTex, 0);
    float ratio = uOutSize.x / float(sz.x);
    if (ratio <= 1.0) {
        o = vec4(texture(uTex, gl_FragCoord.xy / uOutSize).rgb, 1.0);
        return;
    }
    float sx = gl_FragCoord.x / ratio - 0.5;
    int x0 = int(floor(sx));
    int y = int(gl_FragCoord.y);
    vec3 sum = vec3(0.0);
    float wsum = 0.0;
    for (int i = -2; i <= 3; i++) {
        int px = x0 + i;
        float w = lanczos3(sx - float(px));
        sum += texelFetch(uTex, ivec2(clamp(px, 0, sz.x - 1), y), 0).rgb * w;
        wsum += w;
    }
    o = vec4(sum / wsum, 1.0);
}
"""

    /** Vertical Lanczos-3 plus anti-ring against the pre-resample source. Output is (outW x outH). */
    const val LANCZOS_V = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uTex;      // output of horizontal pass
uniform sampler2D uSrc;      // cleaned source, for min/max ring guard
uniform vec2 uOutSize;
uniform float uAntiRing;
out vec4 o;
$LANCZOS_COMMON
void main() {
    ivec2 hs = textureSize(uTex, 0);
    ivec2 ss = textureSize(uSrc, 0);
    float ratioY = uOutSize.y / float(hs.y);
    float ratioX = uOutSize.x / float(ss.x);
    if (ratioY <= 1.0) {
        o = vec4(texture(uTex, gl_FragCoord.xy / uOutSize).rgb, 1.0);
        return;
    }
    float sy = gl_FragCoord.y / ratioY - 0.5;
    int y0 = int(floor(sy));
    int x = int(gl_FragCoord.x);
    vec3 sum = vec3(0.0);
    float wsum = 0.0;
    for (int j = -2; j <= 3; j++) {
        int py = y0 + j;
        float w = lanczos3(sy - float(py));
        sum += texelFetch(uTex, ivec2(x, clamp(py, 0, hs.y - 1)), 0).rgb * w;
        wsum += w;
    }
    vec3 r = sum / wsum;

    // ring guard: clamp to the min/max of the 4 nearest source texels
    float sxs = gl_FragCoord.x / ratioX - 0.5;
    ivec2 b = ivec2(int(floor(sxs)), y0);
    vec3 a0 = texelFetch(uSrc, clamp(b, ivec2(0), ss - 1), 0).rgb;
    vec3 a1 = texelFetch(uSrc, clamp(b + ivec2(1, 0), ivec2(0), ss - 1), 0).rgb;
    vec3 a2 = texelFetch(uSrc, clamp(b + ivec2(0, 1), ivec2(0), ss - 1), 0).rgb;
    vec3 a3 = texelFetch(uSrc, clamp(b + ivec2(1, 1), ivec2(0), ss - 1), 0).rgb;
    vec3 mn = min(min(a0, a1), min(a2, a3));
    vec3 mx = max(max(a0, a1), max(a2, a3));
    r = mix(r, clamp(r, mn, mx), uAntiRing);
    o = vec4(r, 1.0);
}
"""

    /** Wide blur: 16 bilinear taps covering an 8x8 footprint, rendered at 1/4 output size. */
    const val BLUR = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uTex;
uniform vec2 uOutSize;
out vec4 o;
void main() {
    vec2 uv = gl_FragCoord.xy / uOutSize;
    vec2 texel = 1.0 / vec2(textureSize(uTex, 0));
    vec3 sum = vec3(0.0);
    for (int j = 0; j < 4; j++) {
        for (int i = 0; i < 4; i++) {
            vec2 off = vec2(float(i) * 2.0 - 3.0, float(j) * 2.0 - 3.0) * texel;
            sum += texture(uTex, uv + off).rgb;
        }
    }
    o = vec4(sum / 16.0, 1.0);
}
"""

    const val FINISH = """#version 300 es
precision highp float;
precision highp int;
uniform sampler2D uTex;      // upscaled image, NEAREST-safe: read with texelFetch
uniform sampler2D uBlur;     // wide blur, LINEAR
uniform vec2 uOutSize;
uniform float uSharpen;
uniform float uDetail;
uniform float uClarity;
uniform float uAntiRing;
uniform float uGrain;
uniform float uSat;
uniform float uContrast;
uniform float uBright;
uniform float uSeed;
out vec4 o;

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

vec3 fetch(ivec2 p, ivec2 sz) {
    return texelFetch(uTex, clamp(p, ivec2(0), sz - 1), 0).rgb;
}

float hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

void main() {
    ivec2 sz = textureSize(uTex, 0);
    ivec2 p = ivec2(gl_FragCoord.xy);

    vec3 a = fetch(p + ivec2(-1,  1), sz);
    vec3 b = fetch(p + ivec2( 0,  1), sz);
    vec3 c = fetch(p + ivec2( 1,  1), sz);
    vec3 d = fetch(p + ivec2(-1,  0), sz);
    vec3 e = fetch(p, sz);
    vec3 f = fetch(p + ivec2( 1,  0), sz);
    vec3 g = fetch(p + ivec2(-1, -1), sz);
    vec3 h = fetch(p + ivec2( 0, -1), sz);
    vec3 i = fetch(p + ivec2( 1, -1), sz);

    vec3 mn9 = min(min(min(min(a, b), min(c, d)), min(min(e, f), min(g, h))), i);
    vec3 mx9 = max(max(max(max(a, b), max(c, d)), max(max(e, f), max(g, h))), i);

    // ---- contrast adaptive sharpening (FidelityFX CAS style) ----
    vec3 mnP = min(min(min(d, e), min(f, b)), h);
    vec3 mxP = max(max(max(d, e), max(f, b)), h);
    vec3 mnD = min(min(min(a, c), min(g, i)), mnP);
    vec3 mxD = max(max(max(a, c), max(g, i)), mxP);
    vec3 mn = mnP + mnD;
    vec3 mx = mxP + mxD;
    vec3 amp = clamp(min(mn, 2.0 - mx) / max(mx, vec3(1e-4)), 0.0, 1.0);
    amp = sqrt(amp);
    float peak = -1.0 / mix(8.0, 4.0, clamp(uSharpen, 0.0, 1.0));
    vec3 w = amp * peak;
    vec3 rcpW = 1.0 / (1.0 + 4.0 * w);
    vec3 res = ((b + d + f + h) * w + e) * rcpW;
    res = mix(e, res, step(0.001, uSharpen));

    // ---- fine detail boost with noise gate (luma only) ----
    vec3 avg = (a + b + c + d + f + g + h + i + e) / 9.0;
    float hp = luma(res) - luma(avg);
    float gate = smoothstep(0.004, 0.035, abs(hp));
    float boost = clamp(hp * uDetail * 2.2 * gate, -0.14, 0.14);
    res += vec3(boost);

    // ---- clarity: local contrast against wide blur, midtone weighted ----
    vec3 wide = texture(uBlur, gl_FragCoord.xy / uOutSize).rgb;
    float l = luma(res);
    float mid = 1.0 - pow(abs(l * 2.0 - 1.0), 2.0);
    float cl = (l - luma(wide)) * uClarity * 1.4 * mid;
    res += vec3(clamp(cl, -0.18, 0.18));

    // ---- ring / halo guard ----
    float pad = 0.03;
    res = mix(res, clamp(res, mn9 - pad, mx9 + pad), uAntiRing);

    // ---- color ----
    res = (res - 0.5) * uContrast + 0.5 + uBright;
    float ll = luma(res);
    res = mix(vec3(ll), res, uSat);

    // ---- film grain (keeps results from looking plastic) ----
    if (uGrain > 0.001) {
        float n = hash(gl_FragCoord.xy + uSeed) - 0.5;
        float lm = 0.5 + 0.5 * (1.0 - luma(res));
        res += vec3(n * uGrain * 0.12 * lm);
    }

    // ---- dither against 8-bit banding ----
    res += vec3((hash(gl_FragCoord.xy * 1.37 + uSeed * 0.5) - 0.5) / 255.0);

    o = vec4(clamp(res, 0.0, 1.0), 1.0);
}
"""
}
