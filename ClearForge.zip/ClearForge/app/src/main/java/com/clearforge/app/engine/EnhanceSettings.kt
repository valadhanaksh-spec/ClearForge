package com.clearforge.app.engine

/** Target output resolution, expressed as the length of the SHORT side in pixels. */
enum class OutputScale(val label: String, val shortSide: Int?, val factor: Float?) {
    ORIGINAL("Original", null, 1f),
    X1_5("1.5x", null, 1.5f),
    X2("2x", null, 2f),
    X3("3x", null, 3f),
    X4("4x", null, 4f),
    P720("720p", 720, null),
    P1080("1080p", 1080, null),
    P1440("1440p (2K)", 1440, null),
    P2160("2160p (4K)", 2160, null);
}

enum class Codec(val label: String, val mime: String) {
    HEVC("HEVC (H.265)", "video/hevc"),
    AVC("AVC (H.264)", "video/avc")
}

/**
 * Every control maps to a stage in the fragment-shader pipeline.
 * All amounts are 0..1 unless stated otherwise.
 */
data class EnhanceSettings(
    val scale: OutputScale = OutputScale.X2,
    val denoise: Float = 0.30f,        // edge-preserving bilateral denoise
    val deblock: Float = 0.20f,        // softens compression blocking before sharpening
    val sharpen: Float = 0.60f,        // contrast-adaptive sharpening (CAS)
    val detail: Float = 0.35f,         // multi-scale detail / texture boost
    val clarity: Float = 0.30f,        // local contrast (large radius unsharp on luma)
    val antiRing: Float = 0.70f,       // clamp overshoot from Lanczos / sharpen
    val grainRestore: Float = 0.00f,   // re-add fine grain to avoid plastic look
    val saturation: Float = 1.00f,     // 0..2
    val contrast: Float = 1.00f,       // 0.5..1.5
    val brightness: Float = 0.00f,     // -0.3..0.3
    val bitrateMbps: Int = 0,          // 0 = auto from resolution and fps
    val codec: Codec = Codec.HEVC,
    val keepAudio: Boolean = true,
    val targetFps: Int = 0             // 0 = keep source (frame interpolation not included)
)

data class Preset(val name: String, val blurb: String, val settings: EnhanceSettings)

object Presets {
    val all: List<Preset> = listOf(
        Preset(
            "Auto Max", "Balanced, strong clarity for most footage",
            EnhanceSettings(scale = OutputScale.X2, denoise = 0.30f, deblock = 0.20f, sharpen = 0.65f,
                detail = 0.40f, clarity = 0.35f, antiRing = 0.70f)
        ),
        Preset(
            "Ultra Clarity", "Maximum sharpness and detail",
            EnhanceSettings(scale = OutputScale.X2, denoise = 0.25f, deblock = 0.20f, sharpen = 0.90f,
                detail = 0.70f, clarity = 0.60f, antiRing = 0.85f, grainRestore = 0.05f)
        ),
        Preset(
            "Low-Light Clean", "Heavy noise reduction for dark, grainy clips",
            EnhanceSettings(scale = OutputScale.X2, denoise = 0.80f, deblock = 0.30f, sharpen = 0.55f,
                detail = 0.30f, clarity = 0.30f, antiRing = 0.80f, brightness = 0.04f, grainRestore = 0.04f)
        ),
        Preset(
            "Old Footage Restore", "Fixes soft, blocky SD or old phone video",
            EnhanceSettings(scale = OutputScale.P1080, denoise = 0.55f, deblock = 0.75f, sharpen = 0.75f,
                detail = 0.45f, clarity = 0.35f, antiRing = 0.85f, contrast = 1.05f, saturation = 1.08f)
        ),
        Preset(
            "Social Upscale", "Fast 1080p boost for reels and shorts",
            EnhanceSettings(scale = OutputScale.P1080, denoise = 0.25f, deblock = 0.30f, sharpen = 0.55f,
                detail = 0.30f, clarity = 0.25f, antiRing = 0.70f, codec = Codec.AVC)
        ),
        Preset(
            "Anime / Graphics", "Crisp lines, minimal texture noise",
            EnhanceSettings(scale = OutputScale.X2, denoise = 0.45f, deblock = 0.50f, sharpen = 0.80f,
                detail = 0.15f, clarity = 0.10f, antiRing = 0.95f, saturation = 1.05f)
        ),
        Preset(
            "Natural", "Gentle, realistic enhancement",
            EnhanceSettings(scale = OutputScale.X2, denoise = 0.20f, deblock = 0.15f, sharpen = 0.35f,
                detail = 0.20f, clarity = 0.15f, antiRing = 0.60f, grainRestore = 0.03f)
        )
    )
}

/** Work out the output size for a source size. Dimensions are forced even and capped for hardware encoders. */
fun computeOutputSize(srcW: Int, srcH: Int, scale: OutputScale, maxLongSide: Int = 4096): Pair<Int, Int> {
    val factor: Float = when {
        scale.factor != null -> scale.factor
        scale.shortSide != null -> scale.shortSide.toFloat() / minOf(srcW, srcH)
        else -> 1f
    }
    var w = srcW * factor
    var h = srcH * factor
    val longSide = maxOf(w, h)
    if (longSide > maxLongSide) {
        val k = maxLongSide / longSide
        w *= k; h *= k
    }
    val ew = (w.toInt() / 2) * 2
    val eh = (h.toInt() / 2) * 2
    return maxOf(ew, 2) to maxOf(eh, 2)
}
