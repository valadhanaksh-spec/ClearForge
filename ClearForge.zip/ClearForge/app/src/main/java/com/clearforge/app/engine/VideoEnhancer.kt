package com.clearforge.app.engine

import android.content.Context
import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.Executors

data class ExportProgress(
    val fraction: Float,
    val fps: Float,
    val etaSeconds: Int,
    val outW: Int,
    val outH: Int
)

data class ExportResult(
    val file: File,
    val outW: Int,
    val outH: Int,
    val codec: Codec,
    val warnings: List<String>
)

/**
 * Hardware decode -> GPU enhancement pipeline -> hardware encode -> MP4.
 * Audio is stream-copied untouched. Runs entirely on one dedicated GL thread.
 */
class VideoEnhancer(private val context: Context) {

    suspend fun enhance(
        input: Uri,
        output: File,
        settings: EnhanceSettings,
        onProgress: (ExportProgress) -> Unit
    ): ExportResult {
        val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "clearforge-export") }
        try {
            return withContext(executor.asCoroutineDispatcher()) { run(input, output, settings, onProgress) }
        } finally {
            executor.shutdown()
        }
    }

    private suspend fun run(
        input: Uri,
        output: File,
        s: EnhanceSettings,
        onProgress: (ExportProgress) -> Unit
    ): ExportResult {
        val warnings = mutableListOf<String>()
        val extractor = MediaExtractor()
        extractor.setDataSource(context, input, null)

        val vTrack = (0 until extractor.trackCount).firstOrNull {
            extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true
        } ?: run { extractor.release(); throw IllegalArgumentException("No video track found in this file") }

        val vFormat = extractor.getTrackFormat(vTrack)
        val vMime = vFormat.getString(MediaFormat.KEY_MIME)!!
        val srcW = vFormat.getInteger(MediaFormat.KEY_WIDTH)
        val srcH = vFormat.getInteger(MediaFormat.KEY_HEIGHT)
        val durationUs = if (vFormat.containsKey(MediaFormat.KEY_DURATION)) vFormat.getLong(MediaFormat.KEY_DURATION) else 0L
        val rotation = if (vFormat.containsKey(MediaFormat.KEY_ROTATION)) vFormat.getInteger(MediaFormat.KEY_ROTATION) else 0
        val fps = when {
            s.targetFps > 0 -> s.targetFps
            vFormat.containsKey(MediaFormat.KEY_FRAME_RATE) ->
                runCatching { vFormat.getInteger(MediaFormat.KEY_FRAME_RATE) }.getOrDefault(30).coerceIn(10, 120)
            else -> 30
        }
        if (Build.VERSION.SDK_INT >= 24 && vFormat.containsKey(MediaFormat.KEY_COLOR_TRANSFER)) {
            val t = vFormat.getInteger(MediaFormat.KEY_COLOR_TRANSFER)
            if (t == MediaFormat.COLOR_TRANSFER_ST2084 || t == MediaFormat.COLOR_TRANSFER_HLG) {
                warnings += "HDR source detected. Output is encoded as SDR without tone mapping, so colors may look flat."
            }
        }

        val (wantW, wantH) = computeOutputSize(srcW, srcH, s.scale)
        val plan = planEncoder(s.codec, wantW, wantH, fps, s.bitrateMbps)
        if (plan.w != wantW || plan.h != wantH) {
            warnings += "This device's encoder cannot do ${wantW}x$wantH. Exported at ${plan.w}x${plan.h} instead."
        }
        if (plan.codec != s.codec) {
            warnings += "HEVC encoding is not available at this size on this device. Used H.264."
        }

        // lateinit (not nullable) so the local helper functions below can use them without smart-cast issues;
        // the finally block wraps every release in runCatching, which also covers "never initialised".
        lateinit var encoder: MediaCodec
        lateinit var decoder: MediaCodec
        lateinit var muxer: MediaMuxer
        lateinit var egl: EglCore
        lateinit var encSurfaceEgl: android.opengl.EGLSurface
        lateinit var encInput: Surface
        lateinit var decSurface: Surface
        lateinit var surfaceTexture: SurfaceTexture
        lateinit var pipeline: GlPipeline
        var oesTex = 0
        val cbThread = HandlerThread("clearforge-frames").also { it.start() }

        val frameLock = Object()
        var frameReady = false

        try {
            // ---- encoder ----
            val encFormat = MediaFormat.createVideoFormat(plan.codec.mime, plan.w, plan.h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, plan.bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                if (Build.VERSION.SDK_INT >= 23) setInteger(MediaFormat.KEY_PRIORITY, 1)
            }
            encoder = MediaCodec.createByCodecName(plan.encoderName)
            encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encInput = encoder.createInputSurface()
            encoder.start()

            // ---- GL ----
            egl = EglCore(forEncoder = true)
            encSurfaceEgl = egl.createWindowSurface(encInput)
            egl.makeCurrent(encSurfaceEgl)
            pipeline = GlPipeline().also { it.init(); it.configure(srcW, srcH, plan.w, plan.h) }

            val ids = IntArray(1)
            GLES30.glGenTextures(1, ids, 0)
            oesTex = ids[0]
            GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

            surfaceTexture = SurfaceTexture(oesTex)
            surfaceTexture.setOnFrameAvailableListener({
                synchronized(frameLock) { frameReady = true; frameLock.notifyAll() }
            }, Handler(cbThread.looper))
            decSurface = Surface(surfaceTexture)

            // ---- decoder ----
            extractor.selectTrack(vTrack)
            decoder = MediaCodec.createDecoderByType(vMime)
            decoder.configure(vFormat, decSurface, null, 0)
            decoder.start()

            // ---- muxer ----
            output.parentFile?.mkdirs()
            if (output.exists()) output.delete()
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            if (rotation != 0) muxer.setOrientationHint(rotation)

            var muxVideoTrack = -1
            var muxAudioTrack = -1
            var muxerStarted = false
            var audioExtractor: MediaExtractor? = null
            var audioFormat: MediaFormat? = null

            if (s.keepAudio) {
                val ae = MediaExtractor()
                ae.setDataSource(context, input, null)
                val at = (0 until ae.trackCount).firstOrNull {
                    ae.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
                }
                if (at != null) {
                    ae.selectTrack(at)
                    audioExtractor = ae
                    audioFormat = ae.getTrackFormat(at)
                } else {
                    ae.release()
                }
            }

            val info = MediaCodec.BufferInfo()
            var encoderDone = false

            fun startMuxerIfReady(newFormat: MediaFormat) {
                muxVideoTrack = muxer.addTrack(newFormat)
                val af = audioFormat
                if (af != null) {
                    try {
                        muxAudioTrack = muxer.addTrack(af)
                    } catch (e: Exception) {
                        warnings += "Audio could not be copied (${af.getString(MediaFormat.KEY_MIME)}). Exported without sound."
                        audioExtractor?.release(); audioExtractor = null
                    }
                }
                muxer.start()
                muxerStarted = true
            }

            fun drainEncoder(endOfStream: Boolean) {
                var idleSpins = 0
                while (!encoderDone) {
                    val idx = encoder.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
                    when {
                        idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!endOfStream) return
                            if (++idleSpins > 1000) throw IllegalStateException("Encoder stalled while finishing")
                        }
                        idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            check(!muxerStarted) { "Encoder format changed twice" }
                            startMuxerIfReady(encoder.outputFormat)
                        }
                        idx >= 0 -> {
                            idleSpins = 0
                            val buf: ByteBuffer = encoder.getOutputBuffer(idx)!!
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (info.size != 0 && muxerStarted) {
                                buf.position(info.offset)
                                buf.limit(info.offset + info.size)
                                muxer.writeSampleData(muxVideoTrack, buf, info)
                            }
                            encoder.releaseOutputBuffer(idx, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) encoderDone = true
                        }
                    }
                }
            }

            // ---- main loop ----
            var inputDone = false
            var decoderDone = false
            var frames = 0
            var seed = 0f
            val t0 = System.nanoTime()
            var lastReport = 0L

            while (!decoderDone) {
                currentCoroutineContext().ensureActive()

                if (!inputDone) {
                    val inIdx = decoder.dequeueInputBuffer(5_000)
                    if (inIdx >= 0) {
                        val ib = decoder.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(ib, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIdx = decoder.dequeueOutputBuffer(info, 5_000)
                if (outIdx >= 0) {
                    val render = info.size != 0
                    val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    val ptsUs = info.presentationTimeUs
                    decoder.releaseOutputBuffer(outIdx, render)
                    if (render) {
                        synchronized(frameLock) {
                            val deadline = System.currentTimeMillis() + 3_000
                            while (!frameReady) {
                                val left = deadline - System.currentTimeMillis()
                                if (left <= 0) throw IllegalStateException("Decoder produced no frame (timeout)")
                                frameLock.wait(left)
                            }
                            frameReady = false
                        }
                        val tm = FloatArray(16)
                        surfaceTexture.updateTexImage()
                        surfaceTexture.getTransformMatrix(tm)

                        pipeline.loadFromOes(oesTex, tm)
                        seed += 1f
                        pipeline.process(s, seed)
                        egl.setPresentationTime(encSurfaceEgl, ptsUs * 1000L)
                        egl.swap(encSurfaceEgl)
                        frames++

                        val now = System.nanoTime()
                        if (now - lastReport > 250_000_000L) {
                            lastReport = now
                            val elapsed = (now - t0) / 1e9f
                            val rate = frames / elapsed
                            val frac = if (durationUs > 0) (ptsUs.toFloat() / durationUs).coerceIn(0f, 1f) else 0f
                            val eta = if (frac > 0.01f) (elapsed * (1f - frac) / frac).toInt() else -1
                            onProgress(ExportProgress(frac, rate, eta, plan.w, plan.h))
                        }
                    }
                    if (eos) {
                        encoder.signalEndOfInputStream()
                        decoderDone = true
                    }
                }
                drainEncoder(false)
            }
            drainEncoder(true)

            // ---- audio passthrough ----
            val ae = audioExtractor
            if (ae != null && muxerStarted && muxAudioTrack >= 0) {
                val abuf = ByteBuffer.allocateDirect(256 * 1024)
                val ainfo = MediaCodec.BufferInfo()
                while (true) {
                    currentCoroutineContext().ensureActive()
                    abuf.clear()
                    val n = ae.readSampleData(abuf, 0)
                    if (n < 0) break
                    ainfo.set(0, n, ae.sampleTime, if (ae.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    muxer.writeSampleData(muxAudioTrack, abuf, ainfo)
                    ae.advance()
                }
                ae.release()
            }

            check(muxerStarted) { "No video was produced" }
            muxer.stop()
            onProgress(ExportProgress(1f, 0f, 0, plan.w, plan.h))
            return ExportResult(output, plan.w, plan.h, plan.codec, warnings)
        } catch (t: Throwable) {
            runCatching { output.delete() }
            throw t
        } finally {
            runCatching { decoder.stop() }; runCatching { decoder.release() }
            runCatching { encoder.stop() }; runCatching { encoder.release() }
            runCatching { muxer.release() }
            runCatching { decSurface.release() }
            runCatching { surfaceTexture.release() }
            runCatching { encInput.release() }
            runCatching { pipeline.release() }
            runCatching { egl.releaseSurface(encSurfaceEgl) }
            runCatching { egl.release() }
            runCatching { extractor.release() }
            cbThread.quitSafely()
        }
    }

    // ---------------------------------------------------------------- encoder planning

    private data class EncoderPlan(
        val codec: Codec, val encoderName: String, val w: Int, val h: Int, val bitrate: Int
    )

    private fun planEncoder(want: Codec, w: Int, h: Int, fps: Int, userMbps: Int): EncoderPlan {
        val order = if (want == Codec.HEVC) listOf(Codec.HEVC, Codec.AVC) else listOf(Codec.AVC)
        val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { it.isEncoder }

        for (codec in order) {
            val candidates = infos.filter { info -> info.supportedTypes.any { it.equals(codec.mime, true) } }
            // prefer hardware encoders
            val sorted = candidates.sortedBy { if (Build.VERSION.SDK_INT >= 29 && it.isHardwareAccelerated) 0 else 1 }
            for (info in sorted) {
                val vc = info.getCapabilitiesForType(codec.mime).videoCapabilities ?: continue
                var cw = w
                var ch = h
                var tries = 0
                while (tries < 20) {
                    cw -= cw % vc.widthAlignment
                    ch -= ch % vc.heightAlignment
                    if (cw >= 2 && ch >= 2 && vc.isSizeSupported(cw, ch) &&
                        runCatching { vc.areSizeAndRateSupported(cw, ch, fps.toDouble()) }.getOrDefault(true)
                    ) {
                        val pixels = cw.toLong() * ch
                        val bpp = if (codec == Codec.HEVC) 0.085 else 0.13
                        val auto = (pixels * fps * bpp).toLong().coerceIn(2_000_000L, 120_000_000L)
                        val wanted = if (userMbps > 0) userMbps * 1_000_000L else auto
                        val br = wanted.coerceIn(vc.bitrateRange.lower.toLong(), vc.bitrateRange.upper.toLong()).toInt()
                        return EncoderPlan(codec, info.name, cw, ch, br)
                    }
                    cw = (cw * 0.92).toInt()
                    ch = (ch * 0.92).toInt()
                    tries++
                }
            }
        }
        throw IllegalStateException("No hardware video encoder available for this export")
    }
}
