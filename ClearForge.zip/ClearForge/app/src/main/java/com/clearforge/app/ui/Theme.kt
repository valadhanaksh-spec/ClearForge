package com.clearforge.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Accent = Color(0xFF7A86FF)
val Surface0 = Color(0xFF0E0F13)
val Surface1 = Color(0xFF171921)
val Surface2 = Color(0xFF21242F)
val OnSurfaceDim = Color(0xFF9AA0B4)

private val scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF0B0D1F),
    secondary = Color(0xFF5CE1C0),
    background = Surface0,
    surface = Surface1,
    surfaceVariant = Surface2,
    onBackground = Color(0xFFEDEFF7),
    onSurface = Color(0xFFEDEFF7),
    onSurfaceVariant = OnSurfaceDim,
    error = Color(0xFFFF6B6B)
)

private val typography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 40.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp)
)

@Composable
fun ClearForgeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
