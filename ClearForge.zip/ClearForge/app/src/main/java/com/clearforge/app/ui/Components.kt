package com.clearforge.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** Before/after reveal. Drag or tap anywhere to move the split. Both bitmaps cover the same region. */
@Composable
fun CompareView(
    original: Bitmap?,
    enhanced: Bitmap?,
    busy: Boolean,
    modifier: Modifier = Modifier
) {
    var split by remember { mutableFloatStateOf(0.5f) }
    val aspect = if (enhanced != null) enhanced.width.toFloat() / enhanced.height else 16f / 9f

    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(aspect)
            .clip(RoundedCornerShape(16.dp))
            .background(Surface2)
    ) {
        if (original != null && enhanced != null) {
            val o = remember(original) { original.asImageBitmap() }
            val e = remember(enhanced) { enhanced.asImageBitmap() }
            Canvas(
                Modifier
                    .matchParentSize()
                    .pointerInput(Unit) {
                        detectDragGestures { change, _ ->
                            split = (change.position.x / size.width).coerceIn(0f, 1f)
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures { split = (it.x / size.width).coerceIn(0f, 1f) }
                    }
            ) {
                val dst = IntSize(size.width.roundToInt(), size.height.roundToInt())
                drawImage(e, dstOffset = IntOffset.Zero, dstSize = dst, filterQuality = FilterQuality.High)
                val x = size.width * split
                clipRect(left = 0f, top = 0f, right = x, bottom = size.height) {
                    // "before" is a plain bilinear stretch: what a player or editor would show
                    drawImage(
                        o, srcSize = IntSize(o.width, o.height), dstOffset = IntOffset.Zero,
                        dstSize = dst, filterQuality = FilterQuality.Low
                    )
                }
                drawLine(Color.White, Offset(x, 0f), Offset(x, size.height), strokeWidth = 3f)
                drawCircle(Color.White, radius = 18f, center = Offset(x, size.height / 2f))
                drawCircle(Accent, radius = 18f, center = Offset(x, size.height / 2f), style = Stroke(width = 4f))
            }
            Tag("ORIGINAL", Modifier.align(Alignment.TopStart))
            Tag("ENHANCED", Modifier.align(Alignment.TopEnd))
        }
        if (busy || enhanced == null) {
            CircularProgressIndicator(
                Modifier.align(Alignment.Center), color = Accent, strokeWidth = 3.dp
            )
        }
    }
}

@Composable
private fun Tag(text: String, modifier: Modifier) {
    Text(
        text,
        modifier
            .padding(10.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0x99000000))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        color = Color.White,
        fontSize = 10.sp
    )
}

/** Small full-frame thumbnail with a rectangle showing the region the preview is built from. */
@Composable
fun RegionPicker(
    thumb: Bitmap?,
    frameW: Int,
    frameH: Int,
    centerX: Float,
    centerY: Float,
    cropW: Int,
    cropH: Int,
    onMove: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    if (thumb == null) return
    val img = remember(thumb) { thumb.asImageBitmap() }
    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(thumb.width.toFloat() / thumb.height)
            .clip(RoundedCornerShape(12.dp))
    ) {
        Canvas(
            Modifier
                .matchParentSize()
                .pointerInput(Unit) {
                    detectTapGestures { onMove(it.x / size.width, it.y / size.height) }
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        onMove(change.position.x / size.width, change.position.y / size.height)
                    }
                }
        ) {
            drawImage(
                img, dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
                filterQuality = FilterQuality.Medium
            )
            val rw = size.width * (minOf(frameW, cropW).toFloat() / frameW)
            val rh = size.height * (minOf(frameH, cropH).toFloat() / frameH)
            val left = (centerX * size.width - rw / 2f).coerceIn(0f, size.width - rw)
            val top = (centerY * size.height - rh / 2f).coerceIn(0f, size.height - rh)
            drawRect(Color(0x55000000), Offset.Zero, size)
            clipRect(left, top, left + rw, top + rh) {
                drawImage(
                    img, dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
                    filterQuality = FilterQuality.Medium
                )
            }
            drawRect(Accent, Offset(left, top), Size(rw, rh), style = Stroke(width = 3f))
        }
    }
}

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    format: (Float) -> String = { "${(it * 100).roundToInt()}" }
) {
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(format(value), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Accent, activeTrackColor = Accent,
                inactiveTrackColor = Surface2
            )
        )
    }
}
