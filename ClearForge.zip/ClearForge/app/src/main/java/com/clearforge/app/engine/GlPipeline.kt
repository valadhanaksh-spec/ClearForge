package com.clearforge.app.engine

import android.graphics.Bitmap
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.GLUtils
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * Multi-pass GPU enhancement pipeline. All methods must be called on the thread that owns
 * the current EGL context. Pass layout is documented in [GlShaders].
 */
class GlPipeline {

    private class Program(val id: Int) {
        private val cache = HashMap<String, Int>()
        fun loc(name: String): Int = cache.getOrPut(name) { GLES30.glGetUniformLocation(id, name) }
    }

    private class Target(val tex: Int, val fbo: Int, val w: Int, val h: Int)

    private lateinit var copyOes: Program
    private lateinit var copy2d: Program
    private lateinit var clean: Program
    private lateinit var lanH: Program
    private lateinit var lanV: Program
    private lateinit var blur: Program
    private lateinit var finish: Program

    private var vbo = 0
    private var uploadTex = 0
    private var preferHalf = false

    private var srcT: Target? = null
    private var cleanT: Target? = null
    private var hT: Target? = null
    private var upT: Target? = null
    private var blurT: Target? = null
    private var finalT: Target? = null
    private var readback = false

    var outW = 0; private set
    var outH = 0; private set
    var srcW = 0; private set
    var srcH = 0; private set

    private val identity = FloatArray(16).also {
        it[0] = 1f; it[5] = 1f; it[10] = 1f; it[15] = 1f
    }

    fun init() {
        val ext = GLES30.glGetString(GLES30.GL_EXTENSIONS) ?: ""
        preferHalf = ext.contains("GL_EXT_color_buffer_half_float") || ext.contains("GL_EXT_color_buffer_float")

        copyOes = link(GlShaders.VERTEX, GlShaders.COPY_OES)
        copy2d = link(GlShaders.VERTEX, GlShaders.COPY_2D)
        clean = link(GlShaders.VERTEX, GlShaders.CLEAN)
        lanH = link(GlShaders.VERTEX, GlShaders.LANCZOS_H)
        lanV = link(GlShaders.VERTEX, GlShaders.LANCZOS_V)
        blur = link(GlShaders.VERTEX, GlShaders.BLUR)
        finish = link(GlShaders.VERTEX, GlShaders.FINISH)

        val quad = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val fb: FloatBuffer = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder())
            .asFloatBuffer().apply { put(quad); position(0) }
        val ids = IntArray(1)
        GLES30.glGenBuffers(1, ids, 0)
        vbo = ids[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, quad.size * 4, fb, GLES30.GL_STATIC_DRAW)

        GLES30.glGenTextures(1, ids, 0)
        uploadTex = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, uploadTex)
        setParams(GLES30.GL_TEXTURE_2D)
    }

    /** Allocate (or reallocate) the intermediate buffers for the given source and output sizes. */
    fun configure(srcW: Int, srcH: Int, outW: Int, outH: Int, readback: Boolean = false) {
        if (srcW == this.srcW && srcH == this.srcH && outW == this.outW && outH == this.outH &&
            readback == this.readback && srcT != null
        ) return
        freeTargets()
        this.srcW = srcW; this.srcH = srcH; this.outW = outW; this.outH = outH
        this.readback = readback
        srcT = createTarget(srcW, srcH)
        cleanT = createTarget(srcW, srcH)
        hT = createTarget(outW, srcH)
        upT = createTarget(outW, outH)
        blurT = createTarget(maxOf(outW / 4, 2), maxOf(outH / 4, 2))
        // stills and previews render to an RGBA8 target so glReadPixels is always legal
        finalT = if (readback) {
            tryTarget(outW, outH, GLES30.GL_RGBA8, GLES30.GL_UNSIGNED_BYTE)
                ?: throw IllegalStateException("Cannot create ${outW}x$outH readback target")
        } else null
    }

    // ------------------------------------------------------------------ inputs

    /** P0 for video: copy the decoder's external texture into the source-res buffer. */
    fun loadFromOes(oesTex: Int, texMatrix: FloatArray) {
        val t = srcT!!
        use(copyOes)
        begin(t.fbo, t.w, t.h)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES30.glUniform1i(copyOes.loc("uTex"), 0)
        setMatrix(copyOes, texMatrix, 0f)
        draw()
    }

    /** P0 for stills and preview frames. The bitmap must be a software ARGB_8888 bitmap. */
    fun loadFromBitmap(bmp: Bitmap) {
        val t = srcT!!
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, uploadTex)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        use(copy2d)
        begin(t.fbo, t.w, t.h)
        GLES30.glUniform1i(copy2d.loc("uTex"), 0)
        setMatrix(copy2d, identity, 1f)   // bitmap row 0 is the top; GL-up buffers want it at the bottom
        draw()
    }

    // ---------------------------------------------------------------- processing

    /**
     * Run P1..P4. Output lands in whatever framebuffer is bound as the default surface
     * (the encoder window surface, or an offscreen pbuffer for stills).
     */
    fun process(s: EnhanceSettings, seed: Float) {
        val src = srcT!!; val cl = cleanT!!; val h = hT!!; val up = upT!!; val bl = blurT!!

        // P1 clean
        use(clean)
        begin(cl.fbo, cl.w, cl.h)
        bind(0, src.tex)
        GLES30.glUniform1i(clean.loc("uTex"), 0)
        GLES30.glUniform1f(clean.loc("uDenoise"), s.denoise)
        GLES30.glUniform1f(clean.loc("uDeblock"), s.deblock)
        setMatrix(clean, identity, 0f)
        draw()

        // P2a horizontal Lanczos
        use(lanH)
        begin(h.fbo, h.w, h.h)
        bind(0, cl.tex)
        GLES30.glUniform1i(lanH.loc("uTex"), 0)
        GLES30.glUniform2f(lanH.loc("uOutSize"), h.w.toFloat(), h.h.toFloat())
        setMatrix(lanH, identity, 0f)
        draw()

        // P2b vertical Lanczos + anti-ring
        use(lanV)
        begin(up.fbo, up.w, up.h)
        bind(0, h.tex)
        bind(1, cl.tex)
        GLES30.glUniform1i(lanV.loc("uTex"), 0)
        GLES30.glUniform1i(lanV.loc("uSrc"), 1)
        GLES30.glUniform2f(lanV.loc("uOutSize"), up.w.toFloat(), up.h.toFloat())
        GLES30.glUniform1f(lanV.loc("uAntiRing"), s.antiRing)
        setMatrix(lanV, identity, 0f)
        draw()

        // P3 wide blur for clarity
        use(blur)
        begin(bl.fbo, bl.w, bl.h)
        bind(0, up.tex)
        GLES30.glUniform1i(blur.loc("uTex"), 0)
        GLES30.glUniform2f(blur.loc("uOutSize"), bl.w.toFloat(), bl.h.toFloat())
        setMatrix(blur, identity, 0f)
        draw()

        // P4 finish: to the encoder surface (fbo 0) or, for stills, the readback target
        use(finish)
        begin(finalT?.fbo ?: 0, up.w, up.h)
        bind(0, up.tex)
        bind(1, bl.tex)
        GLES30.glUniform1i(finish.loc("uTex"), 0)
        GLES30.glUniform1i(finish.loc("uBlur"), 1)
        GLES30.glUniform2f(finish.loc("uOutSize"), up.w.toFloat(), up.h.toFloat())
        GLES30.glUniform1f(finish.loc("uSharpen"), s.sharpen)
        GLES30.glUniform1f(finish.loc("uDetail"), s.detail)
        GLES30.glUniform1f(finish.loc("uClarity"), s.clarity)
        GLES30.glUniform1f(finish.loc("uAntiRing"), s.antiRing)
        GLES30.glUniform1f(finish.loc("uGrain"), s.grainRestore)
        GLES30.glUniform1f(finish.loc("uSat"), s.saturation)
        GLES30.glUniform1f(finish.loc("uContrast"), s.contrast)
        GLES30.glUniform1f(finish.loc("uBright"), s.brightness)
        GLES30.glUniform1f(finish.loc("uSeed"), seed)
        setMatrix(finish, identity, 0f)
        draw()
    }

    /** Read the result back as an upright bitmap. Requires configure(..., readback = true). */
    fun readBitmap(): Bitmap {
        val ft = checkNotNull(finalT) { "configure() was not called with readback = true" }
        val w = outW; val h = outH
        val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, ft.fbo)
        GLES30.glReadPixels(0, 0, w, h, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf)
        // GL rows come bottom-first; swap in place so the bitmap is upright
        val row = ByteArray(w * 4)
        val tmp = ByteArray(w * 4)
        for (y in 0 until h / 2) {
            val a = y * w * 4
            val b = (h - 1 - y) * w * 4
            buf.position(a); buf.get(row)
            buf.position(b); buf.get(tmp)
            buf.position(a); buf.put(tmp)
            buf.position(b); buf.put(row)
        }
        buf.position(0)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(buf)
        return bmp
    }

    fun release() {
        freeTargets()
        listOf(copyOes, copy2d, clean, lanH, lanV, blur, finish).forEach { GLES30.glDeleteProgram(it.id) }
        GLES30.glDeleteBuffers(1, intArrayOf(vbo), 0)
        GLES30.glDeleteTextures(1, intArrayOf(uploadTex), 0)
    }

    // ------------------------------------------------------------------- helpers

    private fun freeTargets() {
        listOf(srcT, cleanT, hT, upT, blurT, finalT).forEach {
            if (it != null) {
                GLES30.glDeleteFramebuffers(1, intArrayOf(it.fbo), 0)
                GLES30.glDeleteTextures(1, intArrayOf(it.tex), 0)
            }
        }
        srcT = null; cleanT = null; hT = null; upT = null; blurT = null; finalT = null
        srcW = 0; srcH = 0; outW = 0; outH = 0
    }

    private fun createTarget(w: Int, h: Int): Target {
        if (preferHalf) {
            val t = tryTarget(w, h, GLES30.GL_RGBA16F, GLES30.GL_HALF_FLOAT)
            if (t != null) return t
            preferHalf = false
        }
        return tryTarget(w, h, GLES30.GL_RGBA8, GLES30.GL_UNSIGNED_BYTE)
            ?: throw IllegalStateException("Cannot create ${w}x$h render target")
    }

    private fun tryTarget(w: Int, h: Int, internal: Int, type: Int): Target? {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        val tex = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, internal, w, h, 0, GLES30.GL_RGBA, type, null)
        setParams(GLES30.GL_TEXTURE_2D)
        GLES30.glGenFramebuffers(1, ids, 0)
        val fbo = ids[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo)
        GLES30.glFramebufferTexture2D(
            GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, tex, 0
        )
        val ok = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) == GLES30.GL_FRAMEBUFFER_COMPLETE
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        if (!ok) {
            GLES30.glDeleteFramebuffers(1, intArrayOf(fbo), 0)
            GLES30.glDeleteTextures(1, intArrayOf(tex), 0)
            return null
        }
        return Target(tex, fbo, w, h)
    }

    private fun setParams(target: Int) {
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(target, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
    }

    private fun use(p: Program) = GLES30.glUseProgram(p.id)

    private fun begin(fbo: Int, w: Int, h: Int) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo)
        GLES30.glViewport(0, 0, w, h)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
    }

    private fun bind(unit: Int, tex: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
    }

    private fun setMatrix(p: Program, m: FloatArray, flipY: Float) {
        GLES30.glUniformMatrix4fv(p.loc("uTexMatrix"), 1, false, m, 0)
        GLES30.glUniform1f(p.loc("uFlipY"), flipY)
    }

    private fun draw() {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun link(vs: String, fs: String): Program {
        val v = compile(GLES30.GL_VERTEX_SHADER, vs)
        val f = compile(GLES30.GL_FRAGMENT_SHADER, fs)
        val id = GLES30.glCreateProgram()
        GLES30.glAttachShader(id, v)
        GLES30.glAttachShader(id, f)
        GLES30.glLinkProgram(id)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(id, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES30.glGetProgramInfoLog(id)
            GLES30.glDeleteProgram(id)
            throw IllegalStateException("Program link failed: $log")
        }
        GLES30.glDeleteShader(v)
        GLES30.glDeleteShader(f)
        return Program(id)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(s)
            GLES30.glDeleteShader(s)
            throw IllegalStateException("Shader compile failed: $log")
        }
        return s
    }
}
