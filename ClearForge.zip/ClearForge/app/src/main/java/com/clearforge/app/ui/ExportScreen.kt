package com.clearforge.app.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.clearforge.app.service.ExportService
import com.clearforge.app.service.ExportUiState
import java.util.Locale

@Composable
fun ExportScreen(vm: MainViewModel, onFinished: () -> Unit) {
    val state by vm.export.collectAsState()
    val ctx = LocalContext.current

    Column(
        Modifier.fillMaxSize().background(Surface0).statusBarsPadding().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        when (val s = state) {
            is ExportUiState.Running -> {
                val p = s.progress
                Text("Enhancing video", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text(s.sourceName, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Spacer(Modifier.height(28.dp))
                if (p == null || p.fraction <= 0f) {
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = Accent, trackColor = Surface2)
                } else {
                    LinearProgressIndicator(
                        progress = { p.fraction }, modifier = Modifier.fillMaxWidth(),
                        color = Accent, trackColor = Surface2
                    )
                }
                Spacer(Modifier.height(14.dp))
                if (p != null) {
                    Text(
                        "${(p.fraction * 100).toInt()}%  ·  ${String.format(Locale.US, "%.1f", p.fps)} fps" +
                            if (p.etaSeconds >= 0) "  ·  ${ExportService.formatEta(p.etaSeconds)} left" else "",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "Output ${p.outW}×${p.outH}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "You can leave the app. Export continues in the background.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(28.dp))
                OutlinedButton(onClick = vm::cancelExport) { Text("Cancel") }
            }

            is ExportUiState.Done -> {
                Text("Done", style = MaterialTheme.typography.headlineLarge)
                Spacer(Modifier.height(6.dp))
                Text(
                    "${s.result.outW}×${s.result.outH} · ${s.result.codec.label}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "Saved to Movies/ClearForge",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (s.result.warnings.isNotEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    Column(
                        Modifier.fillMaxWidth().background(Surface2, RoundedCornerShape(12.dp)).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        s.result.warnings.forEach { Text(it, style = MaterialTheme.typography.bodyMedium) }
                    }
                }
                Spacer(Modifier.height(28.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW).setDataAndType(s.savedUri, "video/mp4")
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        )
                    }) { Text("Play") }
                    OutlinedButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).setType("video/mp4")
                            .putExtra(Intent.EXTRA_STREAM, s.savedUri)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        ctx.startActivity(Intent.createChooser(send, "Share video"))
                    }) { Text("Share") }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { vm.resetExport(); onFinished() }) { Text("Close") }
            }

            is ExportUiState.Failed -> {
                Text("Export failed", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(10.dp))
                Text(s.message, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(24.dp))
                Button(onClick = { vm.resetExport() }) { Text("Back to editor") }
            }

            ExportUiState.Idle -> Unit
        }
    }
}
