package com.clearforge.app.service

import android.net.Uri
import com.clearforge.app.engine.EnhanceSettings
import com.clearforge.app.engine.ExportProgress
import com.clearforge.app.engine.ExportResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

sealed interface ExportUiState {
    data object Idle : ExportUiState
    data class Running(val progress: ExportProgress?, val sourceName: String) : ExportUiState
    data class Done(val savedUri: Uri, val result: ExportResult, val displayName: String) : ExportUiState
    data class Failed(val message: String) : ExportUiState
}

data class ExportRequest(val input: Uri, val sourceName: String, val settings: EnhanceSettings)

/** In-process hand-off between the UI and [ExportService]. Both live in the same process. */
object ExportManager {
    private val _state = MutableStateFlow<ExportUiState>(ExportUiState.Idle)
    val state: StateFlow<ExportUiState> = _state

    @Volatile
    var pending: ExportRequest? = null

    fun set(s: ExportUiState) { _state.value = s }

    fun reset() {
        pending = null
        _state.value = ExportUiState.Idle
    }
}
