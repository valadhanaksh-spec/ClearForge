package com.clearforge.app.engine

import android.graphics.Bitmap
import android.opengl.EGLSurface
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

/**
 * Runs the same GPU pipeline on a single bitmap. Used for the live before/after preview
 * and for photo export. Owns one GL thread; safe to call from any coroutine.
 */
class StillProcessor {

    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "clearforge-still-gl") }
    private val dispatcher: CoroutineDispatcher = executor.asCoroutineDispatcher()

    private var egl: EglCore? = null
    private var surface: EGLSurface? = null
    private var pipeline: GlPipeline? = null
    private var seed = 0f

    private fun ensureGl() {
        if (egl != null) return
        val e = EglCore(forEncoder = false)
        val s = e.createPbuffer(1, 1)
        e.makeCurrent(s)
        val p = GlPipeline().also { it.init() }
        egl = e; surface = s; pipeline = p
    }

    /** Enhance [src] with [settings]. The output size follows settings.scale. Returns a new bitmap. */
    suspend fun process(src: Bitmap, settings: EnhanceSettings): Bitmap = withContext(dispatcher) {
        ensureGl()
        val p = pipeline!!
        val (ow, oh) = computeOutputSize(src.width, src.height, settings.scale)
        p.configure(src.width, src.height, ow, oh, readback = true)
        val soft = if (src.config == Bitmap.Config.HARDWARE) src.copy(Bitmap.Config.ARGB_8888, false) else src
        p.loadFromBitmap(soft)
        seed += 1f
        p.process(settings, seed)
        val out = p.readBitmap()
        if (soft !== src) soft.recycle()
        out
    }

    fun release() {
        executor.execute {
            pipeline?.release()
            surface?.let { egl?.releaseSurface(it) }
            egl?.release()
            pipeline = null; surface = null; egl = null
        }
        executor.shutdown()
    }
}
