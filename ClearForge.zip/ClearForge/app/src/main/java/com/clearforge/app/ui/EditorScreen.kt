package com.clearforge.app.ui

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.clearforge.app.engine.Codec
import com.clearforge.app.engine.OutputScale
import com.clearforge.app.engine.Presets
import com.clearforge.app.service.ExportService
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditorScreen(vm: MainViewModel, onClose: () -> Unit, onExport: () -> Unit) {
    val st by vm.state.collectAsState()
    val src = st.source ?: return
    val s = st.settings
    val ctx = LocalContext.current
    val out = vm.outputSize()

    Box(Modifier.fillMaxSize().background(Surface0)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // ---- top bar ----
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
                Column(Modifier.weight(1f)) {
                    Text(src.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text(
                        "${src.width}×${src.height}" + if (out != null) "  →  ${out.first}×${out.second}" else "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Button(onClick = onExport, shape = RoundedCornerShape(12.dp)) {
                    Text(if (src.isVideo) "Export" else "Save")
                }
            }

            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                CompareView(st.cropOriginal, st.cropEnhanced, st.previewBusy)
                Text(
                    "Preview is a native-resolution crop. Drag to compare. Tap the thumbnail to move the region.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                RegionPicker(
                    thumb = st.thumb, frameW = src.width, frameH = src.height,
                    centerX = st.previewCenterX, centerY = st.previewCenterY,
                    cropW = 480, cropH = 320, onMove = vm::setPreviewCenter,
                    modifier = Modifier.fillMaxWidth(0.55f)
                )

                if (src.isVideo && src.durationMs > 0) {
                    LabeledSlider(
                        "Preview frame", st.positionMs.toFloat(), 0f..src.durationMs.toFloat(),
                        onChange = { vm.seekTo(it.toLong()) },
                        format = { fmtTime(it.toLong()) }
                    )
                }

                // ---- presets ----
                SectionTitle("Presets")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(Presets.all) { i, p ->
                        FilterChip(
                            selected = st.presetIndex == i,
                            onClick = { vm.applyPreset(i) },
                            label = { Text(p.name) },
                            leadingIcon = if (st.presetIndex == i) {
                                { Icon(Icons.Rounded.AutoAwesome, null, Modifier.height(18.dp)) }
                            } else null,
                            colors = chipColors()
                        )
                    }
                }
                if (st.presetIndex in Presets.all.indices) {
                    Text(
                        Presets.all[st.presetIndex].blurb,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // ---- upscale ----
                SectionTitle("Upscale")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutputScale.entries.forEach { sc ->
                        FilterChip(
                            selected = s.scale == sc,
                            onClick = { vm.edit { it.copy(scale = sc) } },
                            label = { Text(sc.label) },
                            colors = chipColors()
                        )
                    }
                }
                Text(
                    "Output is capped at 4096 px on the long side so every phone's encoder can handle it.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // ---- enhance ----
                SectionTitle("Enhance")
                LabeledSlider("Sharpen", s.sharpen, 0f..1f, { v -> vm.edit { it.copy(sharpen = v) } })
                LabeledSlider("Detail", s.detail, 0f..1f, { v -> vm.edit { it.copy(detail = v) } })
                LabeledSlider("Clarity", s.clarity, 0f..1f, { v -> vm.edit { it.copy(clarity = v) } })
                LabeledSlider("Denoise", s.denoise, 0f..1f, { v -> vm.edit { it.copy(denoise = v) } })
                LabeledSlider("Deblock (compression)", s.deblock, 0f..1f, { v -> vm.edit { it.copy(deblock = v) } })
                LabeledSlider("Halo guard", s.antiRing, 0f..1f, { v -> vm.edit { it.copy(antiRing = v) } })

                // ---- color ----
                SectionTitle("Color and finish")
                LabeledSlider("Saturation", s.saturation, 0f..2f, { v -> vm.edit { it.copy(saturation = v) } },
                    format = { "%.2f".format(it) })
                LabeledSlider("Contrast", s.contrast, 0.5f..1.5f, { v -> vm.edit { it.copy(contrast = v) } },
                    format = { "%.2f".format(it) })
                LabeledSlider("Brightness", s.brightness, -0.3f..0.3f, { v -> vm.edit { it.copy(brightness = v) } },
                    format = { "%+.2f".format(it) })
                LabeledSlider("Film grain", s.grainRestore, 0f..1f, { v -> vm.edit { it.copy(grainRestore = v) } })

                // ---- output (video only) ----
                if (src.isVideo) {
                    SectionTitle("Output")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Codec.entries.forEach { c ->
                            FilterChip(
                                selected = s.codec == c,
                                onClick = { vm.edit { it.copy(codec = c) } },
                                label = { Text(c.label) },
                                colors = chipColors()
                            )
                        }
                    }
                    LabeledSlider(
                        "Bitrate (0 = auto)", s.bitrateMbps.toFloat(), 0f..100f,
                        { v -> vm.edit { it.copy(bitrateMbps = v.roundToInt()) } },
                        format = { if (it.roundToInt() == 0) "Auto" else "${it.roundToInt()} Mbps" }
                    )
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Keep original audio", Modifier.weight(1f))
                        Switch(checked = s.keepAudio, onCheckedChange = { v -> vm.edit { it.copy(keepAudio = v) } })
                    }
                }

                if (st.savedPhoto != null) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Surface2).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Saved to Pictures/ClearForge", Modifier.weight(1f))
                        TextButton(onClick = {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW).setDataAndType(st.savedPhoto, "image/jpeg")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        }) { Text("Open") }
                    }
                }
                Spacer(Modifier.height(24.dp).navigationBarsPadding())
            }
        }

        val busy = st.busyMessage
        if (st.loading || busy != null) {
            Box(Modifier.fillMaxSize().background(Color(0xAA000000)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(color = Accent)
                    Text(busy ?: "Opening…")
                }
            }
        }
        st.message?.let { msg ->
            Row(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp)
                    .clip(RoundedCornerShape(12.dp)).background(Surface2).padding(start = 16.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(msg, Modifier.weight(1f, fill = false).padding(vertical = 12.dp))
                TextButton(onClick = vm::dismissMessage) { Text("OK") }
            }
        }
    }
}

@Composable
private fun chipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = Accent.copy(alpha = 0.25f),
    selectedLabelColor = Color.White
)

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 6.dp))
}

fun fmtTime(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}
