package com.clearforge.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.clearforge.app.service.ExportUiState
import com.clearforge.app.ui.Accent
import com.clearforge.app.ui.ClearForgeTheme
import com.clearforge.app.ui.EditorScreen
import com.clearforge.app.ui.ExportScreen
import com.clearforge.app.ui.MainViewModel
import com.clearforge.app.ui.Surface0

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ClearForgeTheme {
                App(vm)
            }
        }
    }
}

@Composable
private fun App(vm: MainViewModel) {
    val editor by vm.state.collectAsState()
    val export by vm.export.collectAsState()
    val ctx = androidx.compose.ui.platform.LocalContext.current

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.onPicked(uri)
    }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // export proceeds whether or not the notification is allowed
        vm.startExport()
    }

    fun beginExport() {
        val src = editor.source
        val needsNotif = src?.isVideo == true && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needsNotif) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.startExport()
    }

    val exporting = export !is ExportUiState.Idle
    when {
        exporting -> ExportScreen(vm, onFinished = {})
        editor.source == null -> HomeScreen(
            onPick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) },
            message = editor.message
        )
        else -> EditorScreen(
            vm = vm,
            onClose = vm::closeSource,
            onExport = ::beginExport
        )
    }
}

@Composable
private fun HomeScreen(onPick: () -> Unit, message: String?) {
    Column(
        Modifier.fillMaxSize().background(Surface0).statusBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.VideoLibrary, null, tint = Accent, modifier = Modifier.height(64.dp))
        Spacer(Modifier.height(18.dp))
        Text("ClearForge", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "Upscale, sharpen and clean up video and photos on your phone's GPU. Nothing leaves your device.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(32.dp))
        Button(onClick = onPick, shape = RoundedCornerShape(14.dp)) { Text("Choose video or photo") }
        if (message != null) {
            Spacer(Modifier.height(20.dp))
            Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
